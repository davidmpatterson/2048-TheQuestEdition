# Doge2048
Just a couple of minor tweakts to Gabriele Cirulli's code base [here](https://github.com/gabrielecirulli/2048)

Made just for fun. [Play it here!](http://doge2048.com)


## License
Doge2048 is licensed under the [MIT license.](https://github.com/laferrera/doge2048/blob/master/LICENSE.txt)

